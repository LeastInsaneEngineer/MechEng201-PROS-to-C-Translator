// PROS to C Translator for UoA Mechanical / Mechatronical Engineering 201 Vex Project
// Created by: Khalif Akmaloni
// This translator is so you can emulate, compile and run functions for testing outside of MechEng201 lab sessions.
// This file is to serve as the working file for students.

#include "main.h"

//initialise your functions below this comment



// Initialise your functions above this comment


// Do not forget to set your motor gain in main.h
// Run your program in main
void main()
{
	
}

// Define your functions below this comment.
