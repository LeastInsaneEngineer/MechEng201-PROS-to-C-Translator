#include "main.h"

void student_code()
{
	printf("\noffside call \n");
}